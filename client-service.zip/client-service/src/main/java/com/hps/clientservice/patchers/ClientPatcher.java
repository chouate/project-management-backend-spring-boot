package com.hps.clientservice.patchers;

import com.hps.clientservice.entities.Client;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;

@Component
public class ClientPatcher {
    public static void clientPatcher(Client existingClient, Client incompleteClient) throws IllegalAccessException {
        //GET THE COMPILED VERSION OF THE CLASS
        Class<?> clientClass = Client.class;
        Field[] listFields = clientClass.getDeclaredFields();
        System.out.println("Nombre des champs de la classe Client : "+listFields.length);
        System.out.println("**************************************************");
        for(Field field:listFields){
            System.out.println(field.getName());
            //CANT ACCESS IF THE FIELD IS PRIVATE
            field.setAccessible(true);

            //CHECK IF THE VALUE OF THE FIELD IS NOT NULL, IF NOT UPDATE EXISTING CLIENT
            Object value = field.get(incompleteClient);
            if(value != null){
                field.set(existingClient, value);
            }
            //MAKE THE FIELD PRIVATE AGAIN
            field.setAccessible(false);
        }
    }
}
