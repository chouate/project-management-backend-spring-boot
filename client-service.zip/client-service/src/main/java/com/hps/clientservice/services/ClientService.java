package com.hps.clientservice.services;

import com.hps.clientservice.entities.Client;
import com.hps.clientservice.exceptions.ResourceAlreadyExistException;
import com.hps.clientservice.exceptions.ResourceNotFoundException;
import com.hps.clientservice.repositories.ClientRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientService {
    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }


    public List<Client> getAllClinets(){
        return this.clientRepository.findAll();
    }
    public Client getClientById(Long id){
        return clientRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("le client avec pour id "+id+" Not found."));
    }

//    public Client createNewClient(Client client){
//        return this.clientRepository.save(client);
//    }
    public Client createNewClient(Client client){
        // Avant de rajouter un client on doit vérifier si le code n'existe pas
        Optional<Client> optionalCustomer = this.clientRepository.findByCode(client.getCode());

        // Si le numéro on lève une exception personnalisée ResourceAlreadyExistException
        if (optionalCustomer.isPresent())
            throw new ResourceAlreadyExistException("Le code " +client.getCode()+ " existe déjà");

        // Sinon on insère le client et on retourne ses informations
        return this.clientRepository.save(client);
    }
    public Client updateClient(Long id, Client clientNewData){
        Client clientExisting = this.clientRepository.findById(id)
                        .orElseThrow(()-> new RuntimeException("Client to update not found..."));
        clientExisting.setId(id);
        clientExisting.setName(clientNewData.getName());
        clientExisting.setCode(clientNewData.getCode());
        clientExisting.setActivityDomain(clientNewData.getActivityDomain());
        clientExisting.setStartDate(clientNewData.getStartDate());
        clientExisting.setEndDateEstimate(clientNewData.getEndDateEstimate());
        clientExisting.setContactName(clientNewData.getContactName());
        clientExisting.setContactPhoneNumber(clientNewData.getContactPhoneNumber());
        clientExisting.setContactEmail(clientNewData.getContactEmail());
        clientExisting.setDirectorId(clientNewData.getDirectorId());
        clientExisting.setProjectManagerId(clientNewData.getProjectManagerId());

        return clientRepository.save(clientExisting);
    }

    public void deleteClientById(Long id){
        this.clientRepository.deleteById(id);
    }

}
