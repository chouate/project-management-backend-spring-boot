package com.hps.clientservice.controllers;

import com.hps.clientservice.entities.Client;
import com.hps.clientservice.models.User;
import com.hps.clientservice.patchers.ClientPatcher;
import com.hps.clientservice.restClients.UserRestClient;
import com.hps.clientservice.services.ClientService;
import io.micrometer.core.ipc.http.HttpSender;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import java.util.List;

@RestController
@RequestMapping("/clients")
public class ClientController {
    private final ClientService clientService;
    private final UserRestClient userRestClient;

    private final ClientPatcher clientPatcher;

    public ClientController(ClientService clientService, UserRestClient userRestClient, ClientPatcher clientPatcher) {
        this.clientService = clientService;
        this.userRestClient = userRestClient;
        this.clientPatcher = clientPatcher;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getClientById(@PathVariable Long id){
        Client client = clientService.getClientById(id);
        if(client == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Client with Id: "+id+" Not found, try with other Id.");
        }
        User projectManager = userRestClient.getUserById(client.getProjectManagerId());
        User director = userRestClient.getUserById(client.getDirectorId());
        client.setDirectore(director);
        client.setProjectManager(projectManager);
        return ResponseEntity.ok(client);
    }

    @GetMapping
    public List<Client> getAllClient(){
        List<Client> listClients = this.clientService.getAllClinets();
        listClients.forEach(client -> {
            User director = this.userRestClient.getUserById(client.getDirectorId());
            User projectManager = this.userRestClient.getUserById(client.getProjectManagerId());
            client.setDirectore(director);
            client.setProjectManager(projectManager);
        });
        return listClients;
    }

//    @GetMapping
//    public ResponseEntity<Object> getAllClient(){
//        List<Client> listClients = this.clientService.getAllClinets();
//        listClients.forEach(client -> {
//            User director = this.userRestClient.getUserById(client.getDirectorId());
//            User projectManager = this.userRestClient.getUserById(client.getProjectManagerId());
//            client.setDirectore(director);
//            client.setProjectManager(projectManager);
//        });
//        return new ResponseEntity<>(listClients,HttpStatus.OK);
//    }

    @PostMapping()
    public ResponseEntity<Client> createNewClient(@Valid @RequestBody Client client, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            //return ResponseEntity.badRequest().body("Validation failed");
            System.out.println("La liste des érreurs : "+bindingResult.getAllErrors());
        }else {
            System.out.println("Pas d'érreurs !!");
        }
        Client saved =this.clientService.createNewClient(client);
        return new ResponseEntity<>(saved,HttpStatus.CREATED);
    }

//    @PutMapping("/{id}")
//    public Client updateClient(@PathVariable Long id, @RequestBody Client client){
//        client.setId(id);
//        return this.clientService.updateClient(id, client);
//    }

    //    @PutMapping("/{id}")
//    public ResponseEntity<?> updateClient(@PathVariable Long id, @RequestBody Client client){
//        System.out.println("Appel de la methode put : ");
//        System.out.println(client);
//        if (client == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body("Client with Id: "+id+" Not found.");
//        }
//        client.setId(id);
//        Client clientUpdated = this.clientService.updateClient(id, client);
//        System.out.println("*************** updated client***************** ");
//        System.out.println(clientUpdated);
//        return ResponseEntity.ok(clientUpdated);
//    }

    @PatchMapping("/{id}")
    public ResponseEntity<Client> updateClient2(@PathVariable Long id, @RequestBody Client clientRequestBody){
        //RETRIEVE THE ASSOCIATED CLIENT FROM DATABASE THROUGH ITS ID
        Client existingClient = this.clientService.getClientById(id);

        try {
            //SEND BOTH THE EXISTING CLIENT AND THE INCOMPLETE CLIENT TO THE CLIENTPATCHER
            clientPatcher.clientPatcher(existingClient, clientRequestBody);
            //SAVE THE UPDATED EXISTING Client
            this.clientService.updateClient(id, existingClient);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        existingClient.setId(id);
        return ResponseEntity.status(HttpStatus.OK).body(existingClient);
    }



    @DeleteMapping("/{id}")
    public void deleteClientById(@PathVariable Long id){
        this.clientService.deleteClientById(id);
    }

}
