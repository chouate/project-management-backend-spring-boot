package com.hps.clientservice.controllers;

import com.hps.clientservice.exceptions.ResourceAlreadyExistException;
import com.hps.clientservice.exceptions.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static com.hps.clientservice.MyHttpResponse.response;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptins(MethodArgumentNotValidException exception){
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error -> {
            errors.put(error.getField(), error.getDefaultMessage());
        });
        return new  ResponseEntity<>(errors,HttpStatus.BAD_REQUEST );
    }

//    // On definit le type d'exception
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    public ResponseEntity<Object> methodArgumentNotValidException(MethodArgumentNotValidException exception)
//    {
//        // On crée un map qui va contenir le nom des champs et le message qui ne repondent pas aux contraintes
//        Map<String, String> errors = exception.getBindingResult()
//                .getFieldErrors()
//                .stream()
//                .collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
//
//        // On retourne la reponse avec le code, et la liste des erreurs
//        return response(HttpStatus.BAD_REQUEST, "NOK", errors);
//    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> resourceNotFoundException(ResourceNotFoundException exception)
    {
        return response(HttpStatus.NOT_FOUND, exception.getMessage(), null);
    }
    @ExceptionHandler(ResourceAlreadyExistException.class)
    public ResponseEntity<Object> resourceAlreadyExistException(ResourceAlreadyExistException exception)
    {
        //Cette fois le code http est 409, ce qui indique qu'il y'a un conflit
        return response(HttpStatus.CONFLICT, exception.getMessage(), null);
    }


}
