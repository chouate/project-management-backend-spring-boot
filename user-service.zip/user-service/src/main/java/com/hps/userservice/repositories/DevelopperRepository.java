package com.hps.userservice.repositories;

import com.hps.userservice.entities.Developer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DevelopperRepository extends JpaRepository<Developer, Long> {
}
