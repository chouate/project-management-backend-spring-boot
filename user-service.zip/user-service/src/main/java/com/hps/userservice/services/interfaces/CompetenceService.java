package com.hps.userservice.services.interfaces;

import com.hps.userservice.entities.Competence;
import org.springframework.stereotype.Service;

import java.util.List;


public interface CompetenceService {
    List<Competence> getAllCompetence();
    Competence getCompetenceById(Long id);
    Competence createCompetence(Competence competence);
    Competence updateCompetence(Long id, Competence competence);
    void deleteCompetence(Long id);
}
