package com.hps.userservice.services.implementations;

import com.hps.userservice.entities.Competence;
import com.hps.userservice.repositories.CompetenceRepository;
import com.hps.userservice.services.interfaces.CompetenceService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompetenceServiceImp implements CompetenceService {
    private final CompetenceRepository competenceRepository;

    public CompetenceServiceImp(CompetenceRepository competenceRepository) {
        this.competenceRepository = competenceRepository;
    }

    @Override
    public List<Competence> getAllCompetence() {
        return competenceRepository.findAll();
    }

    @Override
    public Competence getCompetenceById(Long id) {
        return this.competenceRepository.findById(id).orElse(null);
    }

    @Override
    public Competence createCompetence(Competence competence) {
        return competenceRepository.save(competence);
    }

    @Override
    public Competence updateCompetence(Long id, Competence competence) {
        competence.setId(id);
        return competenceRepository.save(competence);
    }

    @Override
    public void deleteCompetence(Long id) {
        competenceRepository.deleteById(id);
    }
}
