package com.hps.userservice.services.implementations;

import com.hps.userservice.entities.Developer;
import com.hps.userservice.repositories.DevelopperRepository;
import com.hps.userservice.services.interfaces.DevelopperService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DevelopperServiceImp implements DevelopperService {
    private DevelopperRepository developperRepository;

    public DevelopperServiceImp(DevelopperRepository developperRepository) {
        this.developperRepository = developperRepository;
    }

    @Override
    public List<Developer> getAllDeveloppers() {
        return developperRepository.findAll();
    }

    @Override
    public Developer getDevelopperById(Long id) {
        return developperRepository.findById(id).orElse(null);
    }

    @Override
    public Developer createDeveloper(Developer developper) {
        return developperRepository.save(developper);
    }

    @Override
    public Developer updateDevelpper(Long id, Developer developper) {
        developper.setId(id);
        return developperRepository.save(developper);
    }

    @Override
    public void deleteDevelopperById(Long id) {
        developperRepository.deleteById(id);
    }
}
