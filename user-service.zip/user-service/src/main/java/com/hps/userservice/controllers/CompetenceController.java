package com.hps.userservice.controllers;


import com.hps.userservice.entities.Competence;
import com.hps.userservice.services.interfaces.CompetenceService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("competences")
public class CompetenceController {
    private final CompetenceService competenceService;

    public CompetenceController(CompetenceService competenceService) {
        this.competenceService = competenceService;
    }

    @GetMapping
    public List<Competence> getALLCompetence(){
        return competenceService.getAllCompetence();
    }

    @GetMapping("/{id}")
    public Competence getCompetenceById(@PathVariable Long id){
        return competenceService.getCompetenceById(id);
    }

    @PostMapping()
    public Competence createNewCompetence(@RequestBody Competence competence){
        return competenceService.createCompetence(competence);
    }

    @PutMapping("/{id}")
    public Competence updateCmpetence(@PathVariable Long id, @RequestBody Competence competence){
        return competenceService.updateCompetence(id,competence);
    }

    @DeleteMapping("/{id}")
    public void deleteCompetence(@PathVariable Long id){
        this.competenceService.deleteCompetence(id);
    }
}
