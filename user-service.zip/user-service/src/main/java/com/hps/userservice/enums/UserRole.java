package com.hps.userservice.enums;

public enum UserRole {
    DIRECTOR,
    PROJECT_MANAGER,
    DEVELOPER
}
