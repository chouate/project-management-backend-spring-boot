package com.hps.userservice.models;

import java.util.Date;

public class Client {
    private Long id;
    private String name;
    private String code;
    private String activityDomain;
    private Date startDate;
    private Date endDateEstimate;

    private String contactName;
    private String conactPhoneNumber;
    private String contactEmail;
}
