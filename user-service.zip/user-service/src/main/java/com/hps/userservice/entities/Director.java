package com.hps.userservice.entities;

import com.hps.userservice.models.Client;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Director extends User{
    private String DirectorAttribut;

    @OneToMany(mappedBy = "director")
    private List<Developer> listDevelopers;

    @OneToMany(mappedBy = "director")
    private List<ProjectManager> listProjectManagers;

    @Transient
    private List<Client> listClientsCreated;

    @Override
    public String toString() {
        return "Director{" +super.toString()+
                "DirectorAttribut='" + DirectorAttribut + '\'' +
                '}';
    }
}
