package com.hps.userservice.entities;

import jakarta.persistence.Entity;

import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data @NoArgsConstructor @AllArgsConstructor
public class Developer extends User{
    private String DeveloperAttribut;

    @ManyToOne
    private Director director;

    @ManyToOne
    private ProjectManager projectManager;

    @Override
    public String toString() {
        return "Developer{" +super.toString()+
                "DeveloperAttribut='" + DeveloperAttribut + '\'' +
                '}';
    }
}
