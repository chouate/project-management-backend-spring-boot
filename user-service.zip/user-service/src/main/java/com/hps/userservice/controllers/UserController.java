package com.hps.userservice.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hps.userservice.entities.Developer;
import com.hps.userservice.entities.User;
import com.hps.userservice.enums.UserRole;
import com.hps.userservice.factory.UserFactory;
import com.hps.userservice.services.interfaces.DevelopperService;
import com.hps.userservice.services.interfaces.DirectorService;
import com.hps.userservice.services.interfaces.ProjectManagerService;
import com.hps.userservice.services.interfaces.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService userService;
    private final UserFactory userFactory;
    private final DevelopperService developperService;
    private final ProjectManagerService projectManagerService;
    private final DirectorService directorService;

    public UserController(UserService userService, UserFactory userFactory, DevelopperService developperService, ProjectManagerService projectManagerService, DirectorService directorService) {
        this.userService = userService;
        this.userFactory = userFactory;
        this.developperService = developperService;
        this.projectManagerService = projectManagerService;
        this.directorService = directorService;
    }

    @GetMapping
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id){
        return userService.getUserById(id);
    }

    @PostMapping
    public User createUser(@RequestBody Map<String, Object> userMap) {
        String role = (String) userMap.get("role");
        User user = userFactory.createUserByRole(role);

        // Remplir dynamiquement les champs de user à partir de userMap
        // utiliser ObjectMapper de Jackson pour ça
        ObjectMapper mapper = new ObjectMapper();
        user = mapper.convertValue(userMap, user.getClass());

        return userService.createUser(user);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody Map<String, Object> userMap){
        String role = (String) userMap.get("role");
        User user = userFactory.createUserByRole(role);

        ObjectMapper mapper = new ObjectMapper();
        user= mapper.convertValue(userMap, user.getClass());
        user.setId(id);

        return userService.updateUser(id, user);

    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id){
        userService.deleteUser(id);
    }

    @GetMapping("/role/{role}")
    public List<User> getUserByRole(@PathVariable String role){
        return userService.getUsersByRole(role);
    }
}
