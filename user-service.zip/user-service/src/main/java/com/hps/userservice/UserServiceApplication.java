package com.hps.userservice;

import com.hps.userservice.entities.*;
import com.hps.userservice.enums.UserRole;
import com.hps.userservice.services.interfaces.CompetenceService;
import com.hps.userservice.services.interfaces.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.print.attribute.Attribute;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class UserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(UserService userService, CompetenceService competenceService){
        return args -> {
            Competence competenceJava = new Competence();
            Competence competencePLSQL = new Competence();
            Competence competenceC = new Competence();
            competenceJava.setDescription("Java");
            competencePLSQL.setDescription("PLSQL");
            competenceC.setDescription("C++");

            competenceService.createCompetence(competenceC);
            competenceService.createCompetence(competenceJava);
            competenceService.createCompetence(competencePLSQL);

            List<Competence> competenceList =List.of(
                    competenceJava,competencePLSQL
            );

            Director userDirector = new Director();
            userDirector.setFirstName("mehdi");
            userDirector.setLastName("echeouati");
            userDirector.setEmail("echeouati.elmehdi@gmail.com");
            userDirector.setRole(UserRole.DIRECTOR.toString());
            userDirector.setCompetenceList(competenceList);
            userService.createUser(userDirector);

            ProjectManager projectManager = new ProjectManager();
            projectManager.setFirstName("Jalal");
            projectManager.setLastName("el mhamedi");
            projectManager.setEmail("elmhamedi@gmail.com");
            projectManager.setRole(UserRole.PROJECT_MANAGER.toString());
            projectManager.setCompetenceList(List.of(competenceC));
            userService.createUser(projectManager);

            Developer developer= new Developer();
            developer.setFirstName("hanae");
            developer.setLastName("bendali");
            developer.setEmail("bendali@gmail.com");
            developer.setRole(UserRole.DEVELOPER.toString());
            userService.createUser(developer);

            User user = new User();
            user.setFirstName("nada");
            user.setLastName("aakioui");
            user.setEmail("aakioui@gmail.com");
            user.setRole(UserRole.DEVELOPER.toString());
            userService.createUser(user);

            userService.getAllUsers().forEach(user1 -> {
                System.out.println("user: "+user1.getFirstName()+" role: "+ user1.getRole());
                //System.out.println(user1);

            });


        };
    }
}
